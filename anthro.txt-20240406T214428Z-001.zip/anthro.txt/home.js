// let myTextInput = document.getElementById('fname').value;

function saveToFile(){
    let userInput = document.getElementById('fname').value;

    let blob = new Blob([userInput], {type: 'text/plain'});

    let a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'output.txt';
    a.click();

    document.body.appendChild(a);
}

// // Create a new FileReader object
// let reader = new FileReader();
//
// // Setup the onload event, which will be triggered when the file has been read
// reader.onload = function(event) {
//     // The file's text will be printed here
//     console.log(event.target.result);
// };
//
// // Get the file from the input (assuming an input with id 'file-input')
// let file = document.getElementById('fname').files[0];
//
// // Start reading the file. When it is done, the onload event will be triggered
// reader.readAsText(file);